Bu projede dosya islemleri kullanlarak oluşturulan veri tabanı ile doktor hasta etkileşimi yapılmaya calışılmıştır 

