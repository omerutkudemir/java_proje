package service;

public interface UserInterface {

    void create();
    void delete();

}
